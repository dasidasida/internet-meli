<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>The Pirate Bay - The galaxy's most resilient bittorrent site</title>
    <link href="https://torrindex.net/static/normalize.css" rel="stylesheet" type="text/css">
    <link href="https://torrindex.net/static/tpb.css" rel="stylesheet" type="text/css">
    <link rel="dns-prefetch" href="//apibay.org/">
    <link rel="dns-prefetch" href="//torrindex.net/">
    <script>var country='US';</script>
    <script src="https://thepiratebay.org/static/main.js"></script>
    <script src="https://torrindex.net/static/tinysort.min.js"></script>
    <script data-cfasync="false" src="//d9r4lqt28t1fm.cloudfront.net/?tqlrd=908284"></script>
    <script type='text/javascript' src='//unhappyweakness.com/0c/e3/13/0ce3135c177b20043c5650228182ad9a.js'></script>
    <script data-cfasync="false" src="/sw.js"></script>
</head>
<body id="browse" onload="jswarnclear()">
    <main>
<b><font color="RED"><label id="jscrwarn">Enable JS in your browser!</label></font></b>
<script>document.getElementById("jscrwarn").innerHTML='';</script>
<b><font color="RED"><label id="jscrwarn2">You may be blocking important javascript components, check that main.js is loaded or the webpage won't work.</label></font></b>
        <h1>Details for: <label id="tlt"></label></h1>
        <div class="adblock" id="ad-bottom">
            <div class="ad728 align-center">
<a href="http://ikeanangelsaidthe.com/redirect?tid=855295" style="text-decoration:none; border-bottom:none; color:none;" target="_NEW"><img src="https://torrindex.net/images/epv/728t.png" /></a>            </div>
            <div class="ad468 align-center">
<a href="http://ikeanangelsaidthe.com/redirect?tid=855295" style="text-decoration:none; border-bottom:none; color:none;" target="_NEW"><img src="https://torrindex.net/images/epv/468.png" style="text-decoration:none; border-bottom:none; color:none;" /></a>            </div>
            <div class="ad234 align-center">
            </div>
        </div>
        <div class="browse">
            <section class="col-left ad120">
<a href="http://ikeanangelsaidthe.com/redirect?tid=855295" style="text-decoration:none; border-bottom:none; color:none;" target="_NEW"><img src="https://torrindex.net/images/epv/120.png" /></a>            </section>
            <section class="col-center">
                <div id="description_container">
                    <h2><label id="name"></label></h2>
                    <div id="metadata">
                        <dl id="meta-left" class="col-meta">
                            <div><dt class="dt-sm">Type:</dt><dd><label id="cat"></label></dd></div>
                            <div><dt class="dt-sm">Files:</dt><dd><label id="nfiles"></label></dd></div>
                            <div><dt class="dt-sm">Size:</dt><dd><label id="size"></label></dd></div>
                            <label id="imdb"></label>
                            <br />
                            <div><dt class="dt-md">Uploaded:</dt><dd><label id="uld"></label></dd></div>
                            <div><dt class="dt-md">By:</dt><dd><label id="user"></label></dd></div>
                            <br />
                            <div><dt class="dt-md">Seeders:</dt><dd><label id="s"></label></dd></div>
                            <div><dt class="dt-md">Leechers:</dt><dd><label id="l"></label></dd></div>
                            <div><dt class="dt-md">Info Hash:</dt><dd style="overflow-wrap: break-word; overflow: hidden;"><label id="ih"></label></dd></div>
                        </dl>
                        <dl id="meta-right" class="col-meta">
<a href="http://ikeanangelsaidthe.com/redirect?tid=855295" style="text-decoration:none; border-bottom:none; color:none;" target="_NEW"><img src="https://torrindex.net/images/epv/300.png" /></a>                        </dl>
                    </div>
                    <div class="links">
                        <label id="d"></label>
                    </div>

                    <div id="description_text" class="text-box"><label id="descr"></label></div>

                    <div class="links">
                        <label id="d2"></label>
                    </div>
                    <div id="filelist" class="text-box">
                        <ol>
                            <script>if (typeof make_filelist !== "undefined" ) make_filelist();</script>
                        </ol>
                    </div>

                </div>
            </section>
            <section class="col-right ad120">
<a href="http://ikeanangelsaidthe.com/redirect?tid=855295" style="text-decoration:none; border-bottom:none; color:none;" target="_NEW"><img src="https://torrindex.net/images/epv/160.png" /></a>            </section>
        </div>
        <div class="adblock" id="ad-bottom">
            <div class="ad728 align-center">
<a href="http://ikeanangelsaidthe.com/redirect?tid=855295" style="text-decoration:none; border-bottom:none; color:none;" target="_NEW"><img src="https://torrindex.net/images/epv/728f.png" /></a>            </div>
            <div class="ad468 align-center">
<a href="http://ikeanangelsaidthe.com/redirect?tid=855295" style="text-decoration:none; border-bottom:none; color:none;" target="_NEW"><img src="https://torrindex.net/images/epv/468.png" style="text-decoration:none; border-bottom:none; color:none;" /></a>            </div>
            <div class="ad234 align-center">
            </div>
        </div>
    <script src="https://cdn.jsdelivr.net/npm/bowser@2.9.0/es5.js"></script>
    <script>if (typeof make_details !== "undefined" ) make_details();</script>
    </main>
<header class="row">
<script>print_header1()</script>
<input type="search" title="Pirate Search" name="q" placeholder="Search here..." id="search">
<script>document.getElementById("search").value = getParameterByName('q')</script>
<script>print_header2()</script>
        <section class="col-right ad468" id="had468">
<a href="http://ikeanangelsaidthe.com/redirect?tid=855295" style="text-decoration:none; border-bottom:none; color:none;" target="_NEW"><img src="https://torrindex.net/images/epv/468.png" style="text-decoration:none; border-bottom:none; color:none;" /></a>        </section>
        <section class="col-right ad234" id="had234">
        </section>
</header>
<script>
print_footer();
mark_selected();
</script>
</body>
</html>
